// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        cardAtlas: {
            default: null,
            type: cc.SpriteAtlas
        },
        cardSprite: {
            default: null,
            type: cc.Sprite
        }
    },
    
    onLoad() {
        this.back = true;
        this.cardIndex;
        //图片点击事件，不能用click
        this.cardSprite.node.on(cc.Node.EventType.TOUCH_START, this.flip, this);
    },

    start() { },

    //翻转
    flip: function () {

        if (this.back) {
            console.log("变为正面" + this.cardIndex);
            this.back = false;

            if (selection.length == 1) {
                if (selection[0] == this.cardIndex) {
                    console.log('相同了，可以消除');
                    this.filpAnimation(previousSelection);
                    previousSelection.cardSprite.node.off(cc.Node.EventType.TOUCH_START, previousSelection.flip, previousSelection);
                    cc.loader.loadRes("b", cc.SpriteFrame, function (err, spriteFrame) {
                        previousSelection.node.getComponent(cc.Sprite).spriteFrame = spriteFrame;
                    });
                    this.filpAnimation(this);
                    //解除绑定事件
                    this.cardSprite.node.off(cc.Node.EventType.TOUCH_START, this.flip, this);
                    var self = this;
                    cc.loader.loadRes("b", cc.SpriteFrame, function (err, spriteFrame) {
                        self.node.getComponent(cc.Sprite).spriteFrame = spriteFrame;
                    });
                } else {
                    this.filpAnimation(previousSelection);
                    previousSelection.back = true;
                    cc.loader.loadRes("h", cc.SpriteFrame, function (err, spriteFrame) {
                        previousSelection.node.getComponent(cc.Sprite).spriteFrame = spriteFrame;
                    });
                    this.filpAnimation(this);
                    this.back = true;
                    var self = this;
                    cc.loader.loadRes("h", cc.SpriteFrame, function (err, spriteFrame) {
                        self.node.getComponent(cc.Sprite).spriteFrame = spriteFrame;
                    });
                }
                selection = [];
            } else {
                this.filpAnimation(this);
                previousSelection = this;
                selection.push(this.cardIndex);
                this.node.getComponent(cc.Sprite).spriteFrame = this.cardAtlas.getSpriteFrames()[this.cardIndex];
            }

        } else {
            this.filpAnimation(this);
            console.log("变为反面" + this.cardIndex);
            this.back = true;
            selection = [];
            previousSelection = null;
            var self = this;
               
            cc.loader.loadRes("h", cc.SpriteFrame, function (err, spriteFrame) {
                self.node.getComponent(cc.Sprite).spriteFrame = spriteFrame;
            });
        }
        //let spriteIndex = +sprite.spriteFrame.name;//取的name是字符串类型，+转为整型
    },


    filpAnimation: function(theOne) {
        //卡牌翻转动作
        if (theOne.back) {
            let rotationTo = cc.rotateTo(0.5, 0, 180);
            theOne.cardSprite.node.runAction(rotationTo);
        } else {
            let rotationTo = cc.rotateTo(0.5, 0, 360);
            theOne.cardSprite.node.runAction(rotationTo);
        }
        theOne.cardSprite.node.setScale(cc.v2(1, 1));//完成翻转
    },

    randBall: function (randIndex) {
        this.cardIndex = randIndex;

        var self = this;
        cc.loader.loadRes("h", cc.SpriteFrame, function (err, spriteFrame) {
            self.node.getComponent(cc.Sprite).spriteFrame = spriteFrame;
        });

    },

    // update (dt) {},
});
