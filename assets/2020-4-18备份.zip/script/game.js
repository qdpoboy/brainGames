// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
        startBtn: {
            default: null,
            type: cc.Button
        },
        ballPrefab: {
            default: null,
            type: cc.Prefab
        },
        ctrlArea: {
            default: null,
            type: cc.Node
        }
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad() {
        //记录选中的卡牌
        window.selection = [];
        //上一张选中的卡牌节点
        window.previousSelection = null;
        this.startBtn.node.on('click', this.startGame, this);
    },

    startGame: function () {
        console.log('游戏已开始');
        this.startBtn.node.destroy();
        this.init();
    },

    init: function () {
        this.ballNodeArr = [];
        this.level = 6;
        this.initMap();
    },

    initMap: function () {
        if (this.level > 6) {
            this.level = 6;
        }
        let ballCnt = 6 * this.level;
        // let randArr = [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5];
        let randArr = [1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6];
        for (let i = 0; i < ballCnt; i++) {
            let randIndex = Math.floor(Math.random() * randArr.length);
            let ballNode = cc.instantiate(this.ballPrefab);
            ballNode.getComponent('ball').randBall(randArr[randIndex]);
            randArr.splice(randIndex, 1);
            this.ctrlArea.addChild(ballNode);
            this.ballNodeArr.push(ballNode);
        }
    },

    //start () {},

    // update (dt) {},
});
